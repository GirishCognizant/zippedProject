
import spacy
from spacy.training.example import Example
from spacy.util import minibatch, compounding
import re
import pyodbc

from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
app = Flask(__name__)
CORS(app)
CORS(app, resources={r"/*": {"origins": "*"}})

conn_str = (
    r"Driver={ODBC Driver 17 for SQL Server};"  
    r"Server=LTIN527389,1433;"  
    r"Database=DDS;"  
    r"Trusted_Connection=yes;"
)

TRAINING_DATA = [
    ("CA Acura Dealer Credentials", {"entities": [(0, 2, "STATE"), (3, 8, "BRAND"), (9, 15, "TABLE")]}),
    ("CA Acura Dealer Credential", {"entities": [(0, 2, "STATE"), (3, 8, "BRAND"), (9, 15, "TABLE")]}),
    ("XX yyyyy Dealer Credentials", {"entities": [(0, 2, "STATE"), (3, 8, "BRAND"), (9, 15, "TABLE")]}),
    ("XX yyyyy Dealer Credential", {"entities": [(0, 2, "STATE"), (3, 8, "BRAND"), (9, 15, "TABLE")]}),
    ("Decision status of rule 'Age of oldest trade in Months is < parameter'", {"entities": [ (0, 8, "TABLE"), (25, 69, "DESCRIPTION")]}),
    ("Decision status of rule 'Active credit counseling'", {"entities": [ (0, 8, "TABLE"), (25, 49, "DESCRIPTION")]}),
    ("Decision status of rule 'Approved Tier is < Recommended Tier'", {"entities": [ (0, 8, "TABLE"), (25, 60, "DESCRIPTION")]}),
    ("Decision status of rule 'Bureau Indicates Bankruptcy'", {"entities": [ (0, 8, "TABLE"), (25, 52, "DESCRIPTION")]}),
    ("CA Honda Dealer Credentials", {"entities": [(0, 2, "STATE"), (3, 8, "BRAND"), (9, 15, "TABLE")
        ,(16, 27, "CRED")]}),
    ("CA Honda Dealer Credential", {"entities": [(0, 2, "STATE"), (3, 8, "BRAND"), (9, 15, "TABLE")
        ,(16, 26, "CRED")]}),
    ("CA Motorcycle Dealer Credentials", {"entities": [(0, 2, "STATE"), (3, 13, "BRAND"), (14, 20, "TABLE")
        ,(21, 32, "CRED")]}),
    ("CA Motorcycle Dealer Credential", {"entities": [(0, 2, "STATE"), (3, 13, "BRAND"), (14, 20, "TABLE")
        ,(21, 31, "CRED")]}),

    ("Origenate Credentials in STG for Credit Supervisor profile",
     {"entities": [(0, 9, "TABLE"), (25, 28, "ENV"), (33, 50, "SECURITY_PROFILE")
        ,(10, 21, "CRED")]}),
    ("Origenate Credential in STG for Credit Supervisor profile",
     {"entities": [(0, 9, "TABLE"), (24, 27, "ENV"), (32, 49, "SECURITY_PROFILE")
         , (10, 20, "CRED")]}),
    ("Origenate Credentials in SIT for Credit Supervisor profile",
     {"entities": [(0, 9, "TABLE"), (25, 28, "ENV"), (33, 50, "SECURITY_PROFILE")
        ,(10, 21, "CRED")]}),
    ("Origenate Credential in SIT for Credit Supervisor profile",
     {"entities": [(0, 9, "TABLE"), (24, 27, "ENV"), (32, 49, "SECURITY_PROFILE")
         , (10, 20, "CRED")]}),
    ("Origenate Credentials in STG for Credit Buyer profile",
     {"entities": [(0, 9, "TABLE"), (25, 28, "ENV"), (33, 45, "SECURITY_PROFILE")
        ,(10, 21, "CRED")]}),
    ("Origenate Credential in STG for Credit Buyer profile",
     {"entities": [(0, 9, "TABLE"), (24, 27, "ENV"), (32, 44, "SECURITY_PROFILE")
         , (10, 20, "CRED")]}),
    ("Origenate Credentials in SIT for Credit Buyer profile",
     {"entities": [(0, 9, "TABLE"), (25, 28, "ENV"), (33, 45, "SECURITY_PROFILE")
        ,(10, 21, "CRED")]}),
    ("Origenate Credential in SIT for Credit Buyer profile",
     {"entities": [(0, 9, "TABLE"), (24, 27, "ENV"), (32, 44, "SECURITY_PROFILE")
         , (10, 20, "CRED")]}),

    ("Origenate Credentials in STG for Supervisor profile",
     {"entities": [(0, 9, "TABLE"), (25, 28, "ENV"), (33, 43, "SECURITY_PROFILE")
        ,(10, 21, "CRED")]}),
    ("Origenate Credential in STG for Supervisor profile",
     {"entities": [(0, 9, "TABLE"), (24, 27, "ENV"), (32, 42, "SECURITY_PROFILE")
         , (10, 20, "CRED")]}),
    ("Origenate Credentials in SIT for Supervisor profile",
     {"entities": [(0, 9, "TABLE"), (25, 28, "ENV"), (33, 43, "SECURITY_PROFILE")
        ,(10, 21, "CRED")]}),
    ("Origenate Credential in SIT for Supervisor profile",
     {"entities": [(0, 9, "TABLE"), (24, 27, "ENV"), (32, 42, "SECURITY_PROFILE")
         , (10, 20, "CRED")]}),

    # Queries with MAKE
    ("Fetch me vin details for make Honda", {"entities": [(30, 35, "MAKE")]}),
    ("Show vin details for make Toyota", {"entities": [(26, 32, "MAKE")]}),
    ("I need vin details for make Nissan", {"entities": [(28, 34, "MAKE")]}),
    ("Get details for make Ford", {"entities": [(21, 25, "MAKE")]}),

    # Queries with MODEL
    ("VIN for xxxxxxxx 2024 model", {"entities": [(8, 16, "MODEL"), (17, 21, "YEAR")]}),
    ("VIN for xx-x 2024 model", {"entities": [(8, 12, "MODEL"), (13, 17, "YEAR")]}),
    # ("VIN for xxxxx 2024 model", {"entities": [(8, 13, "MODEL"), (14, 18, "YEAR")]}),
    # ("VIN for xxxxxx 2024 model", {"entities": [(8, 14, "MODEL"), (15, 19, "YEAR")]}),
    # ("VIN for xxxxxxxxxx 2024 model", {"entities": [(8, 18, "MODEL"), (15, 19, "YEAR")]}),
    ("2024 xxxxxxxx VIN", {"entities": [(5, 13, "MODEL"), (0, 4, "YEAR")]}),
    ("Fetch me vin details for model xxxxxx", {"entities": [(31, 37, "MODEL")]}),
    ("Show vin details for model xxxxx", {"entities": [(27, 32, "MODEL")]}),
    ("Give me vin details for model xxxxx", {"entities": [(30, 35, "MODEL")]}),
    ("Get details for model Pilot", {"entities": [(22, 27, "MODEL")]}),
    ("Fetch me 10 Toyota model vins", {"entities": [(9, 11, "LIMIT"), (12, 18, "MODEL")]}),
    ("10 Toyota model vins", {"entities": [(0, 2, "LIMIT"), (3, 9, "MODEL")]}),
    ("5 example model vins", {"entities": [(0, 1, "LIMIT"), (2, 9, "MODEL")]}),
    ("5 honda model vins", {"entities": [(0, 1, "LIMIT"), (2, 7, "MODEL")]}),
    ("5 rdx model vins", {"entities": [(0, 1, "LIMIT"), (2, 5, "MODEL")]}),
    ("5 xxxx model vins", {"entities": [(0, 1, "LIMIT"), (2, 6, "MODEL")]}),
    ("5 xx-x model vins", {"entities": [(0, 1, "LIMIT"), (2, 6, "MODEL")]}),

    # Queries with YEAR
    ("Fetch me vin details for year 2023", {"entities": [(30, 34, "YEAR")]}),
    ("Fetch me vins for year 1111", {"entities": [(23, 27, "YEAR")]}),
    ("Show vin details for the year 2024", {"entities": [(30, 34, "YEAR")]}),
    ("Get vin details for year 2025", {"entities": [(25, 29, "YEAR")]}),
    ("I need details for year 2022", {"entities": [(24, 28, "YEAR")]}),

    # Queries with VINTYPE
    ("Fetch me vin details for EV type", {"entities": [(25, 27, "VINTYPE")]}),
    ("Show vin details for SUV type", {"entities": [(21, 24, "VINTYPE")]}),
    # ("Get details for Sedan type", {"entities": [(15, 20, "VINTYPE")]}),
    # ("I need vin details for MC type", {"entities": [(24, 26, "VINTYPE")]}),

    # Queries with VIN
    ("Fetch me vin details for vin ABC123", {"entities": [(29, 35, "VIN")]}),
    ("vin details for vin ABC123", {"entities": [(20, 26, "VIN")]}),
    ("vin details for vin ABCDefghij1234567", {"entities": [(20, 37, "VIN")]}),
    ("vin details for ABCDefghij1234567", {"entities": [(16, 33, "VIN")]}),
    ("vin details for 23CDefghij1234567", {"entities": [(16, 33, "VIN")]}),
    ("Get details for vin XYZ987", {"entities": [(20, 26, "VIN")]}),
    ("details of vin XYZ987", {"entities": [(15, 21, "VIN")]}),
    ("Show details for vin LMN456", {"entities": [(21, 27, "VIN")]}),
    ("I need vin details for vin PQR789", {"entities": [(27, 33, "VIN")]}),

    # Queries with LIMIT
    ("Give me 5 Honda vins for the year 2024", {"entities": [(8, 9, "LIMIT"), (10, 15, "MAKE"), (34, 38, "YEAR")]}),
    ("Fetch me 10 Toyota make vins", {"entities": [(9, 11, "LIMIT"), (12, 18, "MAKE")]}),
    ("10 Toyota make vins", {"entities": [(0, 2, "LIMIT"), (3, 9, "MAKE")]}),
    ("5 honda make vins", {"entities": [(0, 1, "LIMIT"), (2, 7, "MAKE")]}),
    ("Get 3 vins for Civic model", {"entities": [(4, 5, "LIMIT"), (15, 20, "MODEL")]}),
    ("3 vins for Civic model", {"entities": [(0, 1, "LIMIT"), (11, 16, "MODEL")]}),
    ("Get 3 vins for model Civic", {"entities": [(4, 5, "LIMIT"), (21, 26, "MODEL")]}),
    ("3 vins for model Civic", {"entities": [(0, 1, "LIMIT"), (17, 22, "MODEL")]}),
    ("I need 2 SUV vins", {"entities": [(7, 8, "LIMIT"), (9, 12, "MODEL")]}),
    ("honda civic 2021 vins", {"entities": [(0, 5, "MAKE"), (6, 11, "MODEL"), (12, 16, "YEAR")]}),

    # Queries with MAKE and YEAR
    ("Give me vin details for make Ford and year 2020", {"entities": [(29, 33, "MAKE"), (43, 47, "YEAR")]}),
    ("Show vin details for make Tesla and year 2021", {"entities": [(26, 31, "MAKE"), (41, 45, "YEAR")]}),
    ("Get details for make Nissan for year 2022", {"entities": [(21, 27, "MAKE"), (37, 41, "YEAR")]}),

    # Queries with MODEL and YEAR
    ("Fetch me vin details for model Pilot and year 2023", {"entities": [(31, 36, "MODEL"), (46, 50, "YEAR")]}),
    ("Show details for model Accord of year 2024", {"entities": [(23, 29, "MODEL"), (38, 42, "YEAR")]}),
    ("Give me vin details for model Camry in 2025", {"entities": [(30, 35, "MODEL"), (39, 43, "YEAR")]}),

    # Queries with MAKE and MODEL
    ("Fetch me vin details for make Honda and model CR-V", {"entities": [(30, 35, "MAKE"), (46, 50, "MODEL")]}),
    ("Fetch vin details for make Honda and model CR-V", {"entities": [(27, 32, "MAKE"), (43, 47, "MODEL")]}),
    # ("Show vin details for make Toyota and model Corolla", {"entities": [(21, 27, "MAKE"), (37, 44, "MODEL")]}),

    # Queries with LIMIT, MAKE, and YEAR
    ("Give me 5 Toyota vins for the year 2024", {"entities": [(8, 9, "LIMIT"), (10, 16, "MAKE"), (35, 39, "YEAR")]}),
    ("I need 10 Honda vins for year 2023", {"entities": [(7, 9, "LIMIT"), (10, 15, "MAKE"), (30, 34, "YEAR")]}),

    # Queries with multiple attributes (MAKE, MODEL, YEAR, VINTYPE)
    ("Fetch vin details for make Honda, model Accord, and year 2023", {"entities": [(27, 32, "MAKE"), (40, 46, "MODEL"), (57, 61, "YEAR")]}),
    # ("Show vin details for make Ford, model Escape, vintype SUV, year 2024", {"entities": [(21, 25, "MAKE"), (33, 39, "MODEL"), (49, 52, "VINTYPE"), (58, 62, "YEAR")]}),

    # Queries with LIMIT and multiple attributes
    ("Give me 3 Toyota vins for model Corolla and year 2023", {"entities": [(8, 9, "LIMIT"), (10, 16, "MAKE"), (32, 39, "MODEL"), (49, 53, "YEAR")]}),
    ("Fetch 10 vins for make Nissan, model Altima, year 2022", {"entities": [(6, 8, "LIMIT"), (23, 29, "MAKE"), (37, 43, "MODEL"), (50, 54, "YEAR")]}),
    ("10 vins for make Nissan, model Altima, year 2022", {"entities": [(0, 2, "LIMIT"), (17, 23, "MAKE"), (31, 37, "MODEL"), (44, 48, "YEAR")]}),
    ("10 Nissan make vins", {"entities": [(0, 2, "LIMIT"), (3, 9, "MAKE")]}),
    ("10 accord make vins", {"entities": [(0, 2, "LIMIT"), (3, 9, "MAKE")]}),
    ("5 Nissan make vins", {"entities": [(0, 1, "LIMIT"), (2, 8, "MAKE")]}),

    # Queries with MODEL
    ("VIN for CIVIC 2024 model", {"entities": [(8, 13, "MODEL"), (14, 18, "YEAR")]}),
    ("VIN for Prologue 2024 model", {"entities": [(8, 16, "MODEL"), (17, 21, "YEAR")]}),
    ("VIN for CR-V 2024 model", {"entities": [(8, 12, "MODEL"), (13, 17, "YEAR")]}),
    ("2024 Prologue VIN", {"entities": [(5, 13, "MODEL"), (0, 4, "YEAR")]}),
    ("Show vin details for model Civic", {"entities": [(27, 32, "MODEL")]}),
    ("Give me vin details for model Camry", {"entities": [(30, 35, "MODEL")]}),

    # Queries with YEAR
    ("Fetch me vin details for year 2023", {"entities": [(30, 34, "YEAR")]}),
    ("Show vin details for the year 2024", {"entities": [(30, 34, "YEAR")]}),

    # Queries with VIN
    ("vin details for vin ABC123", {"entities": [(20, 26, "VIN")]}),
    ("vin details for vin LMN456", {"entities": [(20, 26, "VIN")]}),

    # Queries with LIMIT and TABLE
    ("Give me 5 Toyota vins for the year 2024", {"entities": [(8, 9, "LIMIT"), (10, 16, "MAKE"), (35, 39, "YEAR")]}),

    # Queries with TABLE and multiple attributes
    ("Show vin details for make Ford, model Escape, and year 2024", {"entities": [(26, 30, "MAKE"), (38, 44, "MODEL"), (55, 59, "YEAR")]}),


    # ("List all people with fico score above 700", {"entities": [(21, 31, "COLUMN"), (32, 37, "OPERATOR"), (38, 41, "FICO_SCORE")]}),
    # ("Show first name and last name of people in California", {"entities": [(5, 15, "COLUMN"), (20, 29, "COLUMN"), (43, 53, "STATE")]}),
    # ("Get city and zip code for individuals with fico score under 600", {"entities": [(4, 8, "COLUMN"), (13, 21, "COLUMN"), (43, 53, "COLUMN"), (54, 59, "OPERATOR"), (60, 63, "FICO_SCORE")]}),
    # ("What are the first and last names of people with fico score of 750 in Texas?", {"entities": [(13, 18, "COLUMN"), (23, 32, "COLUMN"), (49, 59, "COLUMN"), (63, 66, "FICO_SCORE"), (70, 75, "STATE")]}),
    # ("Show fico score for people living in New York", {"entities": [(5, 15, "COLUMN"), (37, 45, "CITY")]}),
    # ("List zip codes for everyone with a fico score below 650", {"entities": [(5, 13, "COLUMN"), (35, 45, "COLUMN"), (46, 51, "OPERATOR"), (52, 55, "FICO_SCORE")]}),
    # ("Fetch the last names of people from Chicago", {"entities": [(10, 19, "COLUMN"), (36, 43, "CITY")]}),
    # ("Retrieve first name, last name, and fico score for individuals in Arizona", {"entities": [(9, 19, "COLUMN"), (21, 30, "COLUMN"), (36, 46, "COLUMN"), (60, 67, "STATE")]}),
    # ("What are the cities and zip codes of people with a fico score above 720?", {"entities": [(13, 18, "COLUMN"), (23, 31, "COLUMN"), (42, 52, "COLUMN"), (53, 58, "OPERATOR"), (59, 62, "FICO_SCORE")]}),
    # ("Get first and middle names of people with zip code 12345", {"entities": [(4, 9, "COLUMN"), (14, 25, "COLUMN"), (41, 49, "COLUMN"), (50, 55, "ZIP_CODE")]}),
    # ("List all people with fico score above 700", {"entities": [(19, 30, "COLUMN"), (31, 36, "OPERATOR"), (37, 40, "FICO_SCORE")]}),
    # ("Get people with fico score below 600", {"entities": [(16, 27, "COLUMN"), (28, 33, "OPERATOR"), (34, 37, "FICO_SCORE")]}),
    # ("Retrieve people with fico score at least 650", {"entities": [(19, 30, "COLUMN"), (31, 39, "OPERATOR"), (40, 43, "FICO_SCORE")]}),
    # ("List all with fico score at most 750", {"entities": [(13, 24, "COLUMN"), (25, 32, "OPERATOR"), (33, 36, "FICO_SCORE")]}),
]


def train_spacy_model(training_data, iterations=20):
    nlp = spacy.blank("en")
    ner = nlp.add_pipe("ner", last=True)

    for _, annotations in training_data:
        for ent in annotations.get("entities"):
            ner.add_label(ent[2])

    with nlp.disable_pipes([pipe for pipe in nlp.pipe_names if pipe != "ner"]):
        optimizer = nlp.begin_training()
        for _ in range(iterations):
            losses = {}
            batches = minibatch(training_data, size=compounding(4.0, 32.0, 1.001))
            for batch in batches:
                examples = [Example.from_dict(nlp.make_doc(text), annotations) for text, annotations in batch]
                nlp.update(examples, drop=0.35, losses=losses)
            print("Losses:", losses)
    return nlp


# Train the model
nlp = train_spacy_model(TRAINING_DATA)


class SQLQueryGenerator:
    def __init__(self, nlp):
        self.table_name = 'vindetails'
        self.nlp = nlp

    def parse_question(self, question):
        doc = self.nlp(question.lower())
        entities = {"columns": []}  # Initialize with an empty column list

        for ent in doc.ents:
            if ent.label_ == "MAKE":
                entities["make"] = ent.text.capitalize()
            elif ent.label_ == "MODEL":
                entities["model"] = ent.text.capitalize()
            elif ent.label_ == "YEAR":
                entities["year"] = ent.text
            elif ent.label_ == "VINTYPE":
                entities["vintype"] = ent.text.upper()
            elif ent.label_ == "VIN":
                entities["vin"] = ent.text.upper()
            elif ent.label_ == "STATE":
                print(f"state:::{ent.text.upper()}")
                entities["state"] = ent.text.upper()
            elif ent.label_ == "BRAND":
                print(f"brand:::{ent.text.upper()}")
                entities["brand"] = ent.text.upper()
            elif ent.label_ == "DECISION_STATUS":
                print(f"decision_status:::{ent.text.upper()}")
                entities["decision_status"] = ent.text.upper()
            elif ent.label_ == "ENV":
                print(f"env:::{ent.text.upper()}")
                entities["env"] = ent.text.upper()
            elif ent.label_ == "SECURITY_PROFILE":
                print(f"SECURITY_PROFILE:::{ent.text.upper()}")
                entities["security_profile"] = ent.text.upper()
            elif ent.label_ == "LIMIT":
                entities["limit"] = ent.text
            elif ent.label_ == "COLUMN":
                entities["columns"].append(ent.text)
            elif ent.label_ == "TABLE":
                print(f"TABLE:::{ent.text.upper()}")
                if ent.text.lower() == "decision":
                    entities["table"] = "decision_rule"
                else:
                    entities["table"] = ent.text.lower()

        # Fallback regex patterns for entity extraction
        if "vin" not in entities:
            vin_match = re.search(r"\bvin\s+([A-Za-z0-9]+)\b", question, re.IGNORECASE)
            if vin_match:
                entities["vin"] = vin_match.group(1).upper()
        if "make" not in entities:
            make_match = re.search(r"make\s+(\w+)", question, re.IGNORECASE)
            if make_match:
                entities["make"] = make_match.group(1).capitalize()
        if "model" not in entities:
            model_match = re.search(r"model\s+(\w+)", question, re.IGNORECASE)
            if model_match:
                entities["model"] = model_match.group(1).capitalize()
        if "year" not in entities:
            year_match = re.search(r"year\s+(\d{4})", question)
            if year_match:
                entities["year"] = year_match.group(1)
        if "vintype" not in entities:
            vintype_match = re.search(r"vintype\s+(\w+)", question, re.IGNORECASE)
            if vintype_match:
                entities["vintype"] = vintype_match.group(1).upper()
        if "limit" not in entities:
            limit_match = re.search(r"\b(\d+)\b\s*(vin|vins)", question, re.IGNORECASE)
            if limit_match:
                entities["limit"] = limit_match.group(1)
        if not entities["columns"]:
            column_match = re.findall(r"\b(column|columns)\s+(\w+)", question, re.IGNORECASE)
            entities["columns"] = [match[1] for match in column_match]
        if "table" not in entities:
            table_match = re.search(r"auto approve|vindetails|dealer", question, re.IGNORECASE)
            if table_match:
                entities["table"] = table_match.group(0).replace(" ", "_").lower()

        # Default to `vindetails` if no table is mentioned
        if "table" not in entities:
            entities["table"] = "vindetails"

        # Exclude unintended matches like "FOR" being added as a VIN
        if "vin" in entities and entities["vin"] == "FOR":
            del entities["vin"]

        return entities

    def generate_query(self, question):
        entities = self.parse_question(question)
        if not entities:
            return "Sorry, I could not generate a SQL query for that question."

        # Handle column filtering
        columns = ", ".join(entities["columns"]) if entities["columns"] else "*"

        # Handle LIMIT if specified
        limit_clause = f"TOP {entities['limit']} " if "limit" in entities else "TOP 1 "

        # Identify table name
        table_name = entities["table"]

        # Build SQL WHERE clause based on identified entities
        conditions = [f"{column} = '{value}'" for column, value in entities.items() if
                      column not in ["limit", "columns", "table"]]
        condition_string = " AND ".join(conditions)

        return f"SELECT {limit_clause}{columns} FROM {table_name} WHERE {condition_string} ORDER BY NEWID()"

    # def parse_question(self, question):
    #     doc = self.nlp(question.lower())
    #     entities = {}
    #
    #     for ent in doc.ents:
    #         if ent.label_ == "MAKE":
    #             entities["make"] = ent.text.capitalize()
    #         elif ent.label_ == "MODEL":
    #             entities["model"] = ent.text.capitalize()
    #         elif ent.label_ == "YEAR":
    #             print(f"{ent.text}:::{ent}")
    #             entities["year"] = ent.text
    #         elif ent.label_ == "VINTYPE":
    #             entities["vintype"] = ent.text.upper()
    #         elif ent.label_ == "VIN":
    #             entities["vin"] = ent.text.upper()
    #         elif ent.label_ == "LIMIT":
    #             entities["limit"] = ent.text
    #
    #     # Fallback regex patterns for entity extraction
    #     if "vin" not in entities:
    #         vin_match = re.search(r"\bvin\s+([A-Za-z0-9]+)\b", question, re.IGNORECASE)
    #         if vin_match:
    #             entities["vin"] = vin_match.group(1).upper()
    #     if "make" not in entities:
    #         make_match = re.search(r"make\s+(\w+)", question, re.IGNORECASE)
    #         if make_match:
    #             entities["make"] = make_match.group(1).capitalize()
    #     if "model" not in entities:
    #         model_match = re.search(r"model\s+(\w+)", question, re.IGNORECASE)
    #         if model_match:
    #             entities["model"] = model_match.group(1).capitalize()
    #     if "year" not in entities:
    #         year_match = re.search(r"year\s+(\d{4})", question)
    #         if year_match:
    #             print(f"filter:::{year_match.group(1)}")
    #             entities["year"] = year_match.group(1)
    #     if "vintype" not in entities:
    #         vintype_match = re.search(r"vintype\s+(\w+)", question, re.IGNORECASE)
    #         if vintype_match:
    #             entities["vintype"] = vintype_match.group(1).upper()
    #     if "limit" not in entities:
    #         limit_match = re.search(r"\b(\d+)\b\s*(vin|vins)", question, re.IGNORECASE)
    #         if limit_match:
    #             entities["limit"] = limit_match.group(1)
    #
    #     # Additional filtering for `vins` misinterpretation
    #     if entities.get("make") == "Vins":
    #         del entities["make"]
    #
    #     column_match = re.findall(r"show\s+(.*?)\s+(?:from|of)", question, re.IGNORECASE)
    #     if column_match:
    #         entities["columns"] = column_match[0].split(", ")
    #
    #     # Handle Auto-Approve
    #     if "autoapprove" in question or "auto-approve" in question:
    #         entities["autoapprove"] = True
    #
    #     # Fallback regex patterns for other entities
    #     # [Rest of the existing fallback logic remains the same]
    #
    #     return entities

    # def parse_question(self, question):
    #     doc = self.nlp(question.lower())
    #     entities = {"columns": []}  # Initialize with an empty column list
    #
    #     for ent in doc.ents:
    #         if ent.label_ == "MAKE":
    #             entities["make"] = ent.text.capitalize()
    #         elif ent.label_ == "MODEL":
    #             entities["model"] = ent.text.capitalize()
    #         elif ent.label_ == "YEAR":
    #             entities["year"] = ent.text
    #         elif ent.label_ == "VINTYPE":
    #             entities["vintype"] = ent.text.upper()
    #         elif ent.label_ == "VIN":
    #             entities["vin"] = ent.text.upper()
    #         elif ent.label_ == "LIMIT":
    #             entities["limit"] = ent.text
    #         elif ent.label_ == "COLUMN":
    #             entities["columns"].append(ent.text)
    #
    #     # Fallback regex patterns for entity extraction
    #     if "vin" not in entities:
    #         vin_match = re.search(r"\bvin\s+([A-Za-z0-9]+)\b", question, re.IGNORECASE)
    #         if vin_match:
    #             entities["vin"] = vin_match.group(1).upper()
    #     if "make" not in entities:
    #         make_match = re.search(r"make\s+(\w+)", question, re.IGNORECASE)
    #         if make_match:
    #             entities["make"] = make_match.group(1).capitalize()
    #     if "model" not in entities:
    #         model_match = re.search(r"model\s+(\w+)", question, re.IGNORECASE)
    #         if model_match:
    #             entities["model"] = model_match.group(1).capitalize()
    #     if "year" not in entities:
    #         year_match = re.search(r"year\s+(\d{4})", question)
    #         if year_match:
    #             entities["year"] = year_match.group(1)
    #     if "vintype" not in entities:
    #         vintype_match = re.search(r"vintype\s+(\w+)", question, re.IGNORECASE)
    #         if vintype_match:
    #             entities["vintype"] = vintype_match.group(1).upper()
    #     if "limit" not in entities:
    #         limit_match = re.search(r"\b(\d+)\b\s*(vin|vins)", question, re.IGNORECASE)
    #         if limit_match:
    #             entities["limit"] = limit_match.group(1)
    #     if not entities["columns"]:
    #         column_match = re.findall(r"\b(column|columns)\s+(\w+)", question, re.IGNORECASE)
    #         entities["columns"] = [match[1] for match in column_match]
    #
    #     # Exclude unintended matches like "FOR" being added as a VIN
    #     if "vin" in entities and entities["vin"] == "FOR":
    #         del entities["vin"]
    #
    #     return entities
    #
    # def generate_query(self, question):
    #     entities = self.parse_question(question)
    #     if not entities:
    #         return "Sorry, I could not generate a SQL query for that question."
    #
    #     # Handle column filtering
    #     columns = ", ".join(entities["columns"]) if entities["columns"] else "*"
    #
    #     # Handle LIMIT if specified
    #     limit_clause = f"TOP {entities['limit']} " if "limit" in entities else "TOP 1 "
    #
    #     # Build SQL WHERE clause based on identified entities
    #     conditions = [f"{column} = '{value}'" for column, value in entities.items() if
    #                   column not in ["limit", "columns"]]
    #     condition_string = " AND ".join(conditions)
    #
    #     return f"SELECT {limit_clause}{columns} FROM {self.table_name} WHERE {condition_string} ORDER BY NEWID()"

    # def generate_query(self, question):
    #     entities = self.parse_question(question)
    #     if not entities:
    #         return "Sorry, I could not generate a SQL query for that question."
    #
    #     # Handle column selection
    #     columns_clause = ", ".join(entities.get("columns", ["*"]))
    #
    #     # Handle LIMIT if specified
    #     limit_clause = f"TOP {entities['limit']} " if "limit" in entities else "TOP 1 "
    #
    #     # Handle Auto-Approve
    #     if entities.get("autoapprove"):
    #         # Logic for handling auto-approve-related queries
    #         return f"SELECT {limit_clause}{columns_clause} FROM {self.table_name} WHERE status = 'auto-approved'"
    #
    #     # Build SQL WHERE clause based on identified entities
    #     conditions = [f"{column} = '{value}'" for column, value in entities.items() if
    #                   column not in ("limit", "columns", "autoapprove")]
    #     condition_string = " AND ".join(conditions)
    #
    #     return f"SELECT {limit_clause}{columns_clause} FROM {self.table_name} WHERE {condition_string} ORDER BY NEWID()"


# Main function to test the queries
# def main():
#     generator = SQLQueryGenerator(nlp)

    # questions = [
    #     "Fetch me vins for make Honda and model Accord",
    #     "Fetch me vins for year 2023",
    #     "Fetch me vins for vintype Sedan",
    #     "Fetch me vins for vin ABC123",
    #     "Give me 5 Honda vins for the year 2024",
    #     "7 Honda make vins",
    # ]
    #
    # for question in questions:
    #     sql_query = generator.generate_query(question)
    #     print(f"Question: {question}")
    #     print(f"SQL Query: {sql_query}\n")

    # while True:
    #     question = input("Ask away: ")
    #     sql_query = generator.generate_query(question)
    #     print(f"Question: {question}")
    #     print(f"SQL Query: {sql_query}\n")
        # if not sql_query.startswith('Sorry'):
        #     cname = pyodbc.connect(conn_str)
        #     cursor = cname.cursor()
        #     cursor.execute(sql_query)
        #
        #     # print(f'{cursor}')
        #     for row in cursor:
        #         print('row = %r' % (row,))

@app.route('/predict', methods=['POST'])
def getData():
    data = request.get_json()
    question = data.get('question')
    generator = SQLQueryGenerator(nlp)
    sql_query = generator.generate_query(question)
    print(f"Question: {question}")
    print(f"SQL Query: {sql_query}\n")
    if not sql_query.startswith('Sorry'):
        cname = pyodbc.connect(conn_str)
        cursor = cname.cursor()
        cursor.execute(sql_query)
    
        for row in cursor:
            print('row = %r' % (row,))
    return sql_query

# if __name__ == "__main__":
#     main()

# CV state dealerid.
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
//import org.json.JSONObject;
 
@WebServlet("/HelloServlet")
public class HelloServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    public HelloServlet() {
        super();
    }
 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Add CORS headers
response.setHeader("Access-Control-Allow-Origin", "http://localhost:3000");
        response.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        response.setHeader("Access-Control-Allow-Headers", "Content-Type");
 
        // Retrieve parameters
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");
        String option = request.getParameter("option");
 
        // Create response
        response.setContentType("text/html");
        response.getWriter().println("<h1>Selected Dates and Option</h1>");
        response.getWriter().println("<p>Start Date: " + startDate + "</p>");
        response.getWriter().println("<p>End Date: " + endDate + "</p>");
        response.getWriter().println("<p>Selected Option: " + option + "</p>");
//        response.setContentType("application/json");
     // Create a JSON object to hold the response data
//        JSONObject jsonResponse = new JSONObject();
//        jsonResponse.put("startDate", startDate);l
//        jsonResponse.put("endDate", endDate);
//        jsonResponse.put("selectedOption", option);
        
     // Write the JSON object as a string to the response
//        response.getWriter().println(jsonResponse.toString());
    }
}
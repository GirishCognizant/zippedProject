import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 
// Annotation to map the servlet to a specific URL
@WebServlet("/hellogiri")
public class HelloWorldServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
 
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Set the response content type
        response.setContentType("text/html");
        
        // Get the response writer to write to the output
        PrintWriter out = response.getWriter();
        
        // Write the response
        out.println("<html>");
        out.println("<head><title>Hello World Servlet</title></head>");
        out.println("<body>");
        out.println("<h1>Hello, World! giririir</h1>");
        out.println("</body>");
        out.println("</html>");
        
        // Close the writer
        out.close();
    }
}